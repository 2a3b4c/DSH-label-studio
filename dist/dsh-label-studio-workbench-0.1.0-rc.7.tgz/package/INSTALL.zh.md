# Label Studio 工作台插件安装

本教程将预构建的 `dsh-label-studio-workbench` tarball 安装到 DSH `web` Profile，并验证安装、更新和卸载。插件包同时提供 Host、浏览器 Client、协议类型和 `cordis.patch.yml`；安装只修改 Profile，不修改 DeepSeek Harness 的 `packages/` 源码。

## 1. 检查环境

DSH 必须能够运行，`pnpm` 必须在 `PATH` 中。Label Studio 使用名为 `label-studio` 的 conda 环境；下面的非交互命令与进程内执行 `conda activate label-studio` 后启动 Label Studio 等效：

```sh
node --version
pnpm --version
conda run -n label-studio label-studio --version
```

只查看嵌入页面不需要 API 凭据。让模型读取任务、创建项目、修改 annotation 或创建 prediction 前，需要把 Label Studio Account 页面生成的完整 Personal Access Token refresh 值保存为 DSH 凭据 `LABEL_STUDIO_PAT`；不要把真实值写入插件目录、命令参数、聊天记录或 Git。

DSH 默认从 `~/.dsh/.credentials.yaml` 读取受管凭据。文件是一个 YAML mapping，并且在 macOS/Linux 上必须只有当前用户可读写：

```yaml
LABEL_STUDIO_PAT: "在本机填写完整 refresh 值"
```

```sh
chmod 600 ~/.dsh/.credentials.yaml
```

## 2. 安装 tarball

先停止正在运行的 DSH。将变量设为收到的 `.tgz` 文件绝对路径：

```sh
LABEL_STUDIO_TARBALL=/absolute/path/to/dsh-label-studio-workbench-0.1.0-rc.7.tgz
dsh plugin --profile web add --workspace-root "$LABEL_STUDIO_TARBALL"
```

在 DeepSeek Harness 源码仓库中运行 CLI 时，使用仓库声明的 pnpm 版本：

```sh
LABEL_STUDIO_TARBALL=/absolute/path/to/dsh-label-studio-workbench-0.1.0-rc.7.tgz
corepack pnpm dsh plugin --profile web add --workspace-root "$LABEL_STUDIO_TARBALL"
```

`dsh plugin` 把后续参数转发给 Profile 目录内的 pnpm。`--workspace-root` 允许 pnpm 修改该 Profile 工作区的根 `package.json`，它不是 Bundle 配置字段。

安装成功时，输出包含 `dependencies: + dsh-label-studio-workbench`。下面的配置检查应显示 `# == dsh-label-studio-workbench`、disabled 的原 `ui-layout` 和新增的 `label-studio` 行，不应出现单独的 `client-ui-label-studio` 行：

```sh
dsh web --dump-config
```

源码方式使用：

```sh
corepack pnpm dsh web --dump-config
```

## 3. 启动并检查页面

```sh
dsh web
```

源码方式使用 `corepack pnpm dsh web`。打开终端输出的地址，默认是 `http://127.0.0.1:3080`，然后检查：

1. Session 顶部出现 `Label Studio` 入口。
2. 打开入口后，右侧显示 Label Studio，左侧对话保持可用。
3. sidebar、conversation、details、设置和主题切换保持可用。
4. 配置 `LABEL_STUDIO_PAT` 后，`label_studio_*` 工具能够读取当前任务并执行写操作。

插件默认连接 `http://127.0.0.1:8080`。该地址已有 Label Studio 时插件复用它；否则插件通过 `conda run -n label-studio` 启动并管理子进程。

## 4. 更新插件

停止 DSH，取得版本号更高的新 tarball，然后再次执行 `add`：

```sh
NEW_LABEL_STUDIO_TARBALL=/absolute/path/to/dsh-label-studio-workbench-NEW_VERSION.tgz
dsh plugin --profile web add --workspace-root "$NEW_LABEL_STUDIO_TARBALL"
dsh web
```

源码方式仍在命令前加 `corepack pnpm`。正式分发的每个构建都应提升版本号；只有调试同版本本地产物时才增加 pnpm 的 `--force` 参数。

## 5. 卸载并恢复原布局

停止 DSH，然后按 manifest 中的包名卸载，不要传 tarball 文件名：

```sh
dsh plugin --profile web remove --workspace-root dsh-label-studio-workbench
dsh web --dump-config
dsh web
```

卸载成功后，Profile 不再包含 `dsh-label-studio-workbench`，原 `ui-layout` 恢复启用，Label Studio 入口和工具消失。关闭右侧面板只会隐藏 iframe，不等于卸载插件。

## 6. 从本目录重新打包

插件维护者在本目录更新构建产物和版本号后执行：

```sh
corepack pnpm pack --pack-destination ./dist
```

将 `dist/` 中新生成的 `.tgz` 交给使用者即可。tarball 已包含运行所需的 Host、Client 和协议产物，安装时不需要执行 TypeScript 构建脚本。

## 常见错误

| 第一条具体错误 | 处理方法 |
|---|---|
| `ERR_PNPM_ADDING_TO_ROOT` | 安装或卸载命令缺少 `--workspace-root`。 |
| `LABEL_STUDIO_PAT is not configured` | 页面仍可使用，但 REST 工具不可认证；在 DSH 凭据系统中配置完整 refresh 值。 |
| `EADDRINUSE` | 明确停止占用 3080 或 8080 的旧进程后重试。 |
| `Conda environment ... not found` | 确认 `conda run -n label-studio label-studio --version` 成功。 |
| `ELIFECYCLE Command failed with exit code 1` | 这只是 pnpm 汇总；向上查找并处理第一条具体错误。 |
